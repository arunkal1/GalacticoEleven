﻿using Genba_Digital.Utils;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace Genba_Digital_API.Steps
{
    [Binding]
    public class GalacticoElevenStepsAPI
    {
        private string AuthHeader { get; set; }
        private string createdLeagueId { get; set; }
        private string createdLeagueName { get; set; }
        private int createdCompetitionNumber { get; set; }

        /// <summary>
        /// Passes in a string and converts to a RestSharp.Method.
        /// </summary>
        /// <param name="requestType"></param>
        /// <returns></returns>
        public Method DetermineRestRequestMethod(string requestType)
        {
            switch (requestType.ToUpper())
            {
                case "GET":
                    return Method.GET;
                case "POST":
                    return Method.POST;
                case "DELETE":
                    return Method.DELETE;
                case "PATCH":
                    return Method.PATCH;
                case "PUT":
                    return Method.PUT;
                default:
                    return Method.GET;
            }
        }

        /// <summary>
        /// Asserts that the request has successfully returned a response.
        /// </summary>
        /// <param name="response"></param>
        public void AssertResponse(IRestResponse response)
        {
            Assert.AreEqual("OK", response.StatusDescription);
            Assert.AreEqual("Completed", response.ResponseStatus.ToString());
        }

        /// <summary>
        /// Sends the POST request to GalacticoEleven to return the Access Token.
        /// </summary>
        /// <param name="requestURL"></param>
        /// <param name="table"></param>
        [Given(@"the user issues a request to (.*)")]
        public void GivenTheUserIssuesARequestTo_(string requestURL, Table table)
        {
            var dictionary = TableExtensions.ToDictionary(table);

            // Set's up the request URL.
            var client = new RestClient(requestURL);

            // Passes in the request type - converted from 'String' to 'RestRequest'.
            var request = new RestRequest(DetermineRestRequestMethod(dictionary["requestType"]));

            // Adds a JSON body to the request - uses data from the Table.
            request.AddJsonBody(new { email = dictionary["emailAddress"], password = dictionary["password"] });

            // Executes the request with the given URL, Method and Data.
            IRestResponse response = client.Execute(request);

            // Calls assertion method to confirm responses are as expected.
            AssertResponse(response);

            // Set's the authorisation header into a string.
            AuthHeader = "Bearer " + response.Content;
        }

        /// <summary>
        /// Sends a POST request to GalacticoEleven to create a new league.
        /// </summary>
        /// <param name="requestURL"></param>
        /// <param name="table"></param>
        [When(@"the user issues a request to (.*)")]
        public void WhenTheUserIssuesARequestTo_(string requestURL, Table table)
        {
            var dictionary = TableExtensions.ToDictionary(table);

            // Set's up the request URL.
            var client = new RestClient(requestURL);

            // Passes in the request type - converted from 'String' to 'RestRequest'.
            var request = new RestRequest(DetermineRestRequestMethod(dictionary["requestType"]));

            // Adds the Bearer Auth Token to the request.
            request.AddHeader("authorization", AuthHeader);

            // Convert "Competition" string to Int.
            int compNumber = Int32.Parse(dictionary["competition"]);

            // Adds a JSON body to the request - uses data from the Table.
            request.AddJsonBody(new { name = dictionary["leagueName"], competition = compNumber });

            // Executes the request with the given URL, Method and Data.
            IRestResponse response = client.Execute(request);

            // Calls assertion method to confirm responses are as expected.
            AssertResponse(response);

            // Clean's JSON response into .NET Object.
            dynamic parsedJson = JsonConvert.DeserializeObject(response.Content);
            Console.WriteLine(parsedJson);

            // Adds created league to Setters/Getters to use for the assertion later.
            createdLeagueId = parsedJson._id;
            createdLeagueName = parsedJson.name;
            createdCompetitionNumber = parsedJson.competition;
        }

        /// <summary>
        /// Sends a GET request to GalacticoEleven to assert the newly created league exists.
        /// </summary>
        /// <param name="table"></param>
        [Then(@"the user issues a request to (.*)")]
        public void ThenTheUserIssuesARequestTo_(string requestURL, Table table)
        {
            var dictionary = TableExtensions.ToDictionary(table);

            // Set's up the request URL.
            var client = new RestClient(requestURL);

            // Passes in the request type - converted from 'String' to 'RestRequest'.
            var request = new RestRequest(DetermineRestRequestMethod(dictionary["requestType"]));

            // Adds the Bearer Auth Token to the request.
            request.AddHeader("authorization", AuthHeader);

            // Executes the request with the given URL, Method and Data.
            IRestResponse response = client.Execute(request);

            // Calls assertion method to confirm responses are as expected.
            AssertResponse(response);

            // Clean's JSON response into .NET Object.
            dynamic parsedJson = JsonConvert.DeserializeObject(response.Content);

            // Get's the last created league by counting all objects and remove one due to object's index starting from [0].
            int endOfObj = parsedJson.Count - 1;

            // Set the returned id, comp number and league name into string to assert.
            string assertLeagueId = parsedJson[endOfObj]._id;
            int assertCompNum = parsedJson[endOfObj].competition;
            string assertLeagueName = parsedJson[endOfObj].name;

            // Assert that the returned league info matches that of the one created previously.
            Assert.AreEqual(assertLeagueId, createdLeagueId);
            Assert.AreEqual(assertCompNum, createdCompetitionNumber);
            Assert.AreEqual(assertLeagueName, createdLeagueName);
        }
    }
}
