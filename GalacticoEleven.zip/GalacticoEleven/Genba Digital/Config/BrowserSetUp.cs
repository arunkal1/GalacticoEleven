﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace Genba_Digital.Config
{
    public class BrowserSetUp
    {
        // Declare a new instance of the Driver.
        IWebDriver Driver;

        /// <summary>
        /// Set's driver's value to that of the instance set up in CreateWebDriver().
        /// </summary>
        /// <returns>Instance of the Driver</returns>
        public IWebDriver SetUpDriver()
        {
            Driver = CreateWebDriver();
            return Driver;
        }

        /// <summary>
        /// Starts the chrome driver in maximized
        /// Other chrome options can be added
        /// "." - The Nuget package will place the driver.exe file in {buildconfiguration}
        /// Tell's it to look in the root of the application.
        /// This will create a new instance of the driver with the applied options.
        /// </summary>
        /// <returns>Instance of the Driver</returns>
        public IWebDriver CreateWebDriver()
        {
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.AddArgument("start-maximized");
            Driver = new ChromeDriver(".", chromeOptions);
            return Driver;
        }
    }
}
