﻿using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace Genba_Digital.Utils
{
    public class TableExtensions
    {
        /// <summary>
        /// Use System.Collections.Generic to convert a table into a dictionary.
        /// Will accept table data.
        /// </summary>
        /// <param name="table"></param>
        /// <returns>Dictionary with [Key, Value]</returns>
        public static Dictionary<string, string> ToDictionary(Table table)
        {
            var dictionary = new Dictionary<string, string>();
            foreach (var row in table.Rows)
            {
                dictionary.Add(row[0], row[1]);
            }
            return dictionary;
        }
    }
}
