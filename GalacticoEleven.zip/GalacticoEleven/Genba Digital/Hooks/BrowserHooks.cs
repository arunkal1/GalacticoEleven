﻿using Genba_Digital.Config;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace Genba_Digital.Hooks
{
    [Binding]
    public class BrowserHooks
    {
        // Creates an instance of the Driver.
        public static IWebDriver Driver;

        /// <summary>
        /// Before each scenario it will create a new instance of the Driver 
        /// And return the value to this instance of the Driver.
        /// </summary>
        [BeforeScenario]
        public void BeforeTestRun()
        {
            // Set's up an instance of the BrowserSetUp page.
            BrowserSetUp browserSetUp = new BrowserSetUp();
            Driver = browserSetUp.SetUpDriver();
        }

        /// <summary>
        /// Clears down any instance of the driver after each test completion.
        /// </summary>
        [AfterScenario]
        public void AfterScenario()
        {
            Driver.Quit();
        }
    }
}
