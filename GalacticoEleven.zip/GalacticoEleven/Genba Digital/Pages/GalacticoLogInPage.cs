﻿using Genba_Digital.Hooks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Linq;
using System.Threading;

namespace Genba_Digital
{
    public class GalacticoLoginPage
    {
        public IWebDriver Driver;

        /// <summary>
        /// Constructer initialises the driver for the page.
        /// </summary>
        public GalacticoLoginPage()
        {
            Driver = BrowserHooks.Driver;
        }

        // Elements on the page.
        private IWebElement emailInput => 
            Driver.FindElement(By.XPath("//input[@type='email']"));
        private IWebElement passwordInput => 
            Driver.FindElement(By.XPath("//input[@type='password']"));
        private IWebElement loginButton => 
            Driver.FindElement(By.XPath("//div[@class='form-group']//button[contains(.,'Login')]"));

        /// <summary>
        /// Navigates to the login page URL.
        /// </summary>
        /// <param name="loginUrl"></param>
        /// <returns></returns>
        public GalacticoLoginPage NavigateToLoginPage(string loginUrl)
        {
            Driver.Navigate().GoToUrl(loginUrl);
            return new GalacticoLoginPage();
        }

        /// <summary>
        /// Confirms the page has loaded.
        /// Enters the email address.
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        public GalacticoLoginPage EnterEmailAddress(string emailAddress)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(Driver => Driver.FindElements(By.XPath("//input[@type='email']")).FirstOrDefault());

            emailInput.SendKeys(emailAddress);
            return new GalacticoLoginPage();
        }

        /// <summary>
        /// Enters the password.
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public GalacticoLoginPage EnterPassword(string password)
        {
            passwordInput.SendKeys(password);
            return new GalacticoLoginPage();
        }

        /// <summary>
        /// Clicks the login button.
        /// </summary>
        /// <returns></returns>
        public GalacticoLoginPage ClickLoginButton()
        {
            loginButton.Click();
            return new GalacticoLoginPage();
        }
    }
}
