﻿using Genba_Digital.Hooks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genba_Digital.Pages
{
    public class GalacticoLeaguePage
    {
        public IWebDriver Driver;
        private string selectedLeagueName;
        private string selectedTeamName;
        private string chosenCompititionName;
        private Dictionary<string, string> leagueInfoDictionary = new Dictionary<string, string>();

        /// <summary>
        /// Constructor initialises the driver for this page.
        /// </summary>
        public GalacticoLeaguePage()
        {
            Driver = BrowserHooks.Driver;
        }

        // Elements on the page.
        private IWebElement createTabHeader =>
            Driver.FindElement(By.XPath("//li//a[contains(.,'Create')]"));
        private IWebElement leagueNameInput =>
            Driver.FindElement(By.Id("name"));
        private IWebElement teamNameInput =>
            Driver.FindElement(By.Id("team"));
        private IWebElement competitionDropdown =>
            Driver.FindElement(By.Id("competition"));
        private IWebElement createLeagueSubmitButton =>
            Driver.FindElement(By.XPath("//a[@class='btn btn-success']"));
        private IWebElement leagueNumberOne =>
            Driver.FindElement(By.XPath("(//div//h5[@class='ng-binding'])[1]"));
        private IWebElement leagueNumberOneCompitition =>
            Driver.FindElement(By.XPath("(//h5//small[@class='ng-binding'][contains(.,'Competition: ')])[1]"));
        private IWebElement leagueNumberOneTeamName =>
            Driver.FindElement(By.XPath("(//h5//small[@class='ng-binding'][contains(.,'Team: ')])[1]"));

        /// <summary>
        /// Confirms the league home page has loaded.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage ConfirmLeaguePageHasLoaded()
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(Driver => Driver.FindElements(By.XPath("//h1[contains(.,'Leagues')]")).FirstOrDefault());
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Clicks on the create a new league tab.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage ClickOnCreateTabButton()
        {
            createTabHeader.Click();
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Waits for the create league page to load and enters a league name.
        /// </summary>
        /// <param name="leagueName"></param>
        /// <returns></returns>
        public GalacticoLeaguePage EnterLeagueName(string leagueName)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(Driver => Driver.FindElements(By.Id("name")).FirstOrDefault());
            leagueNameInput.SendKeys(leagueName);
            selectedLeagueName = leagueName;
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Enters the team's name. If left blank league will not contain any teams.
        /// </summary>
        /// <param name="teamName"></param>
        /// <returns></returns>
        public GalacticoLeaguePage EnterTeamName(string teamName)
        {
            teamNameInput.SendKeys(teamName);
            selectedTeamName = teamName ;
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Selects a competition from the dropdown.
        /// </summary>
        /// <param name="competitionChosen"></param>
        /// <returns></returns>
        public GalacticoLeaguePage SelectCompitition(string competitionChosen)
        {
            Driver.FindElement(By.XPath($"//select//option[contains(.,'{competitionChosen}')]")).Click();
            chosenCompititionName = competitionChosen;
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Clicks on the create a league button once details are entered.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage ClickCreateLeague()
        {
            createLeagueSubmitButton.Click();
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Confirm that after successful league creation the page is redirected back to the 'Current' tab.
        /// Waits for the current tab to be 'active'.
        /// If not throws an exception.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage ConfirmRedirectedBackToCurrentTab()
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
                wait.Until(Driver => Driver.FindElements(By.XPath("//a[@class='btn btn-primary btn-sm ng-binding ng-scope active'][contains(.,'Current')]")).FirstOrDefault());
            }
            catch (Exception)
            {
                throw new Exception("Error creating new league and/or not directed back to the 'Current' tab");
            }
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Get's the created league information and sorts it to get the neccessary information to assert.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage GetLeagueInformation()
        {
            // Get's the league name information as it is contained within the <H5> tag.
            // LeagueInfo returned the big block - therefore - everything after 'Competition' was stripped.
            string leagueInfo = leagueNumberOne.Text;
            int indexOfCompetition = leagueInfo.IndexOf("Competition");
            leagueInfoDictionary.Add("LeagueName", leagueInfo.Remove(indexOfCompetition).Replace("\r\n", string.Empty));

            // Get's the league compitition name from the <small> tag.
            string leagueComp = leagueNumberOneCompitition.Text;
            leagueInfoDictionary.Add("CompititionTitle", leagueComp.Replace("Competition: ", string.Empty));

            // Get's the league team's name from the <small> tag.
            string teamName = leagueNumberOneTeamName.Text;
            leagueInfoDictionary.Add("TeamName", teamName.Replace("Team: ", string.Empty));

            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Asserts that the league name created is the same as the one shown on screen.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage AssertLeagueNameIsCorrect()
        {
            Assert.AreEqual(selectedLeagueName, leagueInfoDictionary["LeagueName"]);
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Asserts that the compitition selected is the same as the one shown on screen.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage AssertCompititionNameIsCorrect()
        {
            Assert.AreEqual(chosenCompititionName, leagueInfoDictionary["CompititionTitle"]);
            return new GalacticoLeaguePage();
        }

        /// <summary>
        /// Asserts that the team name selected is the same as the one shown on screen.
        /// </summary>
        /// <returns></returns>
        public GalacticoLeaguePage AssertTeamNameIsCorrect()
        {
            Assert.AreEqual(selectedTeamName, leagueInfoDictionary["TeamName"]);
            return new GalacticoLeaguePage();
        }
    }
}
