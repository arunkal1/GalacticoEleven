﻿using Genba_Digital.Pages;
using Genba_Digital.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Genba_Digital.Steps
{
    [Binding]
    public class GalacticoElevenSteps
    {
        // Sets up instance of other pages.
        GalacticoLoginPage galacticoLoginPage = new GalacticoLoginPage();
        GalacticoLeaguePage galacticoLeaguePage = new GalacticoLeaguePage();
        private const string loginUrl = "https://www.galacticoeleven.com/#!/login";

        /// <summary>
        /// Navigates to the Galactico Eleven URL.
        /// Log's in with credentials.
        /// </summary>
        /// <param name="table"></param>
        [Given(@"the user navigates to the Galactico Eleven login page")]
        public void GivenTheUserNavigatesToTheGalacticoElevenLoginPage(Table table)
        {
            var dictionary = TableExtensions.ToDictionary(table);

            galacticoLoginPage.NavigateToLoginPage(loginUrl);
            galacticoLoginPage.EnterEmailAddress(dictionary["emailAddress"]);
            galacticoLoginPage.EnterPassword(dictionary["password"]);
            galacticoLoginPage.ClickLoginButton();
        }

        /// <summary>
        /// Confirms the league's page has loaded.
        /// Clicks on create new league.
        /// Enters new league details.
        /// </summary>
        /// <param name="table"></param>
        [When(@"the user creates a league")]
        public void GivenTheUserCreatesALeague(Table table)
        {
            var dictionary = TableExtensions.ToDictionary(table);

            galacticoLeaguePage.ConfirmLeaguePageHasLoaded();
            galacticoLeaguePage.ClickOnCreateTabButton();
            galacticoLeaguePage.EnterLeagueName(dictionary["leagueName"]);
            galacticoLeaguePage.EnterTeamName(dictionary["teamNameInput"]);
            galacticoLeaguePage.SelectCompitition(dictionary["competitionChosen"]);
            galacticoLeaguePage.ClickCreateLeague();
            galacticoLeaguePage.ConfirmRedirectedBackToCurrentTab();
        }

        /// <summary>
        /// Asserts that the league information created previously is correct.
        /// </summary>
        [Then(@"the user confirms the league created is correct")]
        public void ThenTheUserConfirmsTheLeagueCreatedIsCorrect()
        {
            galacticoLeaguePage.GetLeagueInformation();
            galacticoLeaguePage.AssertLeagueNameIsCorrect();
            galacticoLeaguePage.AssertCompititionNameIsCorrect();
            galacticoLeaguePage.AssertTeamNameIsCorrect();
        }
    }
}
